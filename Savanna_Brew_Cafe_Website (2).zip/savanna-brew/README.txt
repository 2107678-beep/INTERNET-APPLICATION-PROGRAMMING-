SAVANNA BREW CAFE WEBSITE
==========================

Project contents
- index.html       Home page
- about.html       About Us page
- menu.html        Menu and prices
- gallery.html     Photo-style illustration gallery
- contact.html     Contact details, opening hours and reservation form
- css/style.css    Shared responsive stylesheet
- images/          Local SVG artwork used by the pages

HOW TO VIEW
1. Extract the ZIP file.
2. Open the savanna-brew folder.
3. Double-click index.html, or open it with a modern web browser.
4. Use the navigation links to visit all five pages.

NOTES
- The artwork is included as local SVG files so the website images work offline.
- Google Fonts are an optional online enhancement; Georgia and Arial fallbacks are included.
- The reservation form uses HTML required-field validation and a mailto action. It relies on a configured email application and does not store bookings on a server. A real booking system requires a backend or form service.
- Contact details and the .example email address are fictional assignment data.
- The external social links currently point to the social platforms' home pages; update them with the café's real profile URLs if available.

VALIDATION CHECKLIST
Before submission, validate each HTML file at https://validator.w3.org/ and the stylesheet at https://jigsaw.w3.org/css-validator/.
Validation has not been run automatically in this package. Record any remaining validator warnings here after checking:
- HTML warnings/errors: ______________________________
- CSS warnings/errors: _______________________________

GITHUB PAGES
1. Create a GitHub repository (for example, savanna-brew).
2. Upload the contents of this folder to the repository root (not the ZIP file alone).
3. In the repository, open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and /(root), then Save.
6. Wait for GitHub Pages to publish. Your site URL will appear in Settings > Pages.

© 2026 Savanna Brew Café — Student assignment reference project.
