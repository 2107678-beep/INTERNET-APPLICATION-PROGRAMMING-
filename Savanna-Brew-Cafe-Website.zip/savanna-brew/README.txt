SAVANNA BREW CAFE WEBSITE
=========================

Project files
-------------
index.html       Home page
about.html       About Us page
menu.html        Menu and price tables
gallery.html     Responsive photo gallery
contact.html     Contact details and reservation form
css/style.css    Shared external stylesheet
images/          Local image assets

How to view
-----------
1. Extract the ZIP file.
2. Open the savanna-brew folder.
3. Double-click index.html to open the website in a browser.
4. Use the navigation links to visit all five pages.

Notes
-----
- Built with HTML5 and CSS3 only; no JavaScript or CSS framework is used.
- Google Fonts are loaded from Google Fonts when internet access is available.
- The reservation form uses browser validation and a mailto action. It is a front-end demo and does not store reservations on a server.
- The supplied image files are illustrative local placeholders. Replace them with appropriately licensed café photographs before public use.
- Validate each HTML page at https://validator.w3.org/ and the stylesheet at https://jigsaw.w3.org/css-validator/.
- Validation status: prepared for validation; run the validators before submission and record any remaining warnings here.

GitHub Pages
------------
After uploading this folder to a GitHub repository, open repository Settings > Pages.
Choose "Deploy from a branch", select the main branch and the /(root) folder, then Save.
Your site will be published at https://YOUR-USERNAME.github.io/REPOSITORY-NAME/ after deployment.
